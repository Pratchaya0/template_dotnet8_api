﻿namespace $safeprojectname$.Models
{
    public interface IId
    {
        public Guid Id { get; set; }
    }
}
